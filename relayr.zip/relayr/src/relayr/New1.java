package relayr;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.NoSuchElementException;

import org.testng.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.ElementNotVisibleException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;



import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class New1 {
	public WebDriver driver;
	public WebDriverWait wait;
	String appURL = "https://stackoverflow.com/";
	
	//Locators
	private By byEmail = By.id("email");
	private By byPassword = By.id("password");
	private By bySubmit = By.id("submit-button");
	
	
	@BeforeClass
	public void testSetup() {
		System.setProperty("webdriver.chrome.driver", "/Users/sajupt/Desktop/chromedriver");
		driver = new ChromeDriver();
//		driver.manage().window().maximize();
		wait = new WebDriverWait(driver, 5);
		driver.navigate().to(appURL);
		WebElement login;
		login= wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("html/body/header/div/div[2]/div/a[1]")));      
		login.click();
	}
	
	
	@DataProvider(name="empLogin")
	public Object[][] loginData() {
		Object[][] arrayObject = getExcelData("/Users/sajupt/Desktop/Data.xls");
		return arrayObject;
	}
	
	@Test(dataProvider="empLogin")
	public void VerifyInvalidLogin(String userName, String password) throws InterruptedException {
		driver.findElement(byEmail).clear();
		Thread.sleep(3000);
		driver.findElement(byEmail).sendKeys(userName);
		Thread.sleep(3000);
		driver.findElement(byPassword).clear();
		Thread.sleep(3000);
		driver.findElement(byPassword).sendKeys(password);
		Thread.sleep(3000);
		//wait for element to be visible and perform click
//		wait.until(ExpectedConditions.visibilityOfElementLocated(bySubmit));
		driver.findElement(bySubmit).click();
		Thread.sleep(3000);
		
		//Assert.assertTrue(driver.findElement(By.id("submit-button")).isDisplayed(),"Login is successful");
		
		try{
		     if(driver.findElement(By.id("submit-button")).isDisplayed()) 
		     {
		      System.out.println("Login is not successful");    
		     }
		}
		catch(Exception e){
		    	 System.out.println("Login is  successful");    
		     }
	}

	public String[][] getExcelData(String fileName) {
		String[][] arrayExcelData = null;
		try {
			FileInputStream fs = new FileInputStream(fileName);
			Workbook wb = Workbook.getWorkbook(fs);
			Sheet sh = wb.getSheet(0);

			int totalNoOfCols = sh.getColumns();
			int totalNoOfRows = sh.getRows();
			
			arrayExcelData = new String[totalNoOfRows-1][totalNoOfCols];
			
			for (int i= 1 ; i < totalNoOfRows; i++) {

				for (int j=0; j < totalNoOfCols; j++) {
					arrayExcelData[i-1][j] = sh.getCell(j, i).getContents();
				}

			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
			e.printStackTrace();
		} catch (BiffException e) {
			e.printStackTrace();
		}
		return arrayExcelData;
	}
}